# Yolov8-ANPR > 2025-02-07 6:18pm
https://universe.roboflow.com/anpr-8ds14/yolov8-anpr-glygz

Provided by a Roboflow user
License: CC BY 4.0

